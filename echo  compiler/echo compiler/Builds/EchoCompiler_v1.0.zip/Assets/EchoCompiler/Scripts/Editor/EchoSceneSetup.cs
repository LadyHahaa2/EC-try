#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace EchoCompiler.Editor
{
    public static class EchoSceneSetup
    {
        [MenuItem("Tools/Echo/Import TextMeshPro Resources")]
        public static void ImportTextResources()
        {
            TMPro.TMP_PackageResourceImporter.ImportResources(true, false, false);
            AssetDatabase.Refresh();
            Debug.Log("Imported TextMeshPro Essential Resources for the generated HUD.");
        }

        [MenuItem("Tools/Echo/Create Demo Scene")]
        public static void CreateDemoScene()
        {
            var scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
            var camera = Camera.main;
            if (camera != null)
            {
                camera.orthographic = true;
                camera.orthographicSize = 6f;
                camera.backgroundColor = new Color(0.015f, 0.025f, 0.06f, 1f);
                camera.transform.position = new Vector3(0f, 0f, -10f);
            }

            var bootstrap = new GameObject("EchoCompilerBootstrap");
            bootstrap.AddComponent<EchoCompilerBootstrap>();
            EditorSceneManager.SaveScene(scene, "Assets/Scenes/SampleScene.unity");

            EnsureFolder("Assets/EchoCompiler/Data");
            CreateDefinition("Level_01.asset", 0);
            CreateDefinition("Level_02.asset", 1);
            CreateDefinition("Level_03.asset", 2);

            EditorBuildSettings.scenes = new[]
            {
                new EditorBuildSettingsScene("Assets/Scenes/SampleScene.unity", true)
            };
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            Selection.activeGameObject = bootstrap;
            Debug.Log("Echo Compiler demo scene and three LevelDefinition assets created.");
        }

        private static void EnsureFolder(string path)
        {
            if (!AssetDatabase.IsValidFolder(path))
            {
                var parent = path.Substring(0, path.LastIndexOf('/'));
                var name = path.Substring(path.LastIndexOf('/') + 1);
                AssetDatabase.CreateFolder(parent, name);
            }
        }

        private static void CreateDefinition(string filename, int index)
        {
            var path = "Assets/EchoCompiler/Data/" + filename;
            var definition = AssetDatabase.LoadAssetAtPath<LevelDefinition>(path);
            if (definition == null)
            {
                definition = ScriptableObject.CreateInstance<LevelDefinition>();
                AssetDatabase.CreateAsset(definition, path);
            }

            definition.levelId = "level_0" + (index + 1);
            definition.displayName = index == 0 ? "First Echo" : index == 1 ? "Two Nodes" : "Beat Hazard";
            definition.roomSize = new Vector2(18f, 10f);
            definition.playerSpawn = new Vector2(-6.4f, -2.8f);
            definition.exitPosition = new Vector2(6.4f, 2.8f);
            definition.timeLimit = index == 2 ? 90f : 75f;
            definition.echoLimit = 3;
            definition.switches = index == 0
                ? new[] { Point("switch_alpha", -1.1f, -0.4f) }
                : index == 1
                    ? new[] { Point("switch_alpha", -1.9f, -1.1f), Point("switch_beta", -1.9f, 1.1f) }
                    : new[] { Point("switch_alpha", -1.4f, 0f) };
            definition.doors = new[] { Point("door_alpha", 2.8f, index == 0 ? -0.4f : 0f) };
            definition.shards = index == 0 ? new LevelDefinition.PointDefinition[0] : new[] { Point("shard_signal", 0.5f, 2.1f) };
            definition.lasers = index == 2
                ? new[] { new LevelDefinition.LaserDefinition { id = "laser_beat", start = new Vector2(-0.1f, -2.2f), end = new Vector2(-0.1f, 2.2f), period = 2.1f } }
                : new LevelDefinition.LaserDefinition[0];
            EditorUtility.SetDirty(definition);
        }

        private static LevelDefinition.PointDefinition Point(string id, float x, float y)
        {
            return new LevelDefinition.PointDefinition { id = id, position = new Vector2(x, y) };
        }
    }
}
#endif
