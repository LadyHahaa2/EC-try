using System.Collections.Generic;
using UnityEngine;

namespace EchoCompiler
{
    public sealed class EchoPool : MonoBehaviour
    {
        private readonly Queue<EchoAgent> available = new Queue<EchoAgent>(3);
        private readonly List<EchoAgent> active = new List<EchoAgent>(3);
        private Transform parent;
        private RunManager owner;

        public void Prepare(Transform roomParent, RunManager manager)
        {
            ReleaseAll();
            parent = roomParent;
            owner = manager;
            var colors = new[] { new Color(1f, 0.3f, 0.86f), new Color(1f, 0.82f, 0.16f), new Color(0.25f, 0.9f, 1f) };
            for (var i = 0; i < 3; i++)
            {
                var go = RuntimeVisuals.CreateBlock(parent, "EchoPool_" + i, Vector2.zero, new Vector2(0.68f, 0.68f), colors[i], 4);
                go.SetActive(false);
                var body = go.AddComponent<Rigidbody2D>();
                body.gravityScale = 0f;
                body.freezeRotation = true;
                body.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
                body.interpolation = RigidbodyInterpolation2D.Interpolate;
                var collider = go.AddComponent<CircleCollider2D>();
                collider.radius = 0.44f;
                go.AddComponent<LineRenderer>();
                available.Enqueue(go.AddComponent<EchoAgent>());
            }
        }

        public EchoAgent Acquire(InputFrame[] frames, Vector3 start, Color color)
        {
            if (available.Count == 0 || parent == null) return null;
            var agent = available.Dequeue();
            agent.transform.SetParent(parent, false);
            agent.gameObject.SetActive(true);
            agent.Initialize(frames, start, color, owner);
            active.Add(agent);
            return agent;
        }

        public void ReleaseAll()
        {
            for (var i = 0; i < active.Count; i++)
            {
                if (active[i] != null) active[i].gameObject.SetActive(false);
            }
            active.Clear();
            while (available.Count > 0)
            {
                var agent = available.Dequeue();
                if (agent != null) DestroyIfRuntime(agent.gameObject);
            }
        }

        private static void DestroyIfRuntime(GameObject target)
        {
            if (target == null) return;
            if (Application.isPlaying) Destroy(target);
            else DestroyImmediate(target);
        }
    }
}
