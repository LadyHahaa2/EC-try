using UnityEngine;
using UnityEngine.Profiling;

namespace EchoCompiler
{
    public sealed class PerfOverlay : MonoBehaviour
    {
        private float elapsed;
        private int frames;
        private float fps;

        public string Snapshot { get; private set; } = "FPS -- | GC --";

        private void Update()
        {
            elapsed += Time.unscaledDeltaTime;
            frames++;
            if (elapsed < 0.5f) return;
            fps = frames / elapsed;
            frames = 0;
            elapsed = 0f;
            Snapshot = string.Format("FPS {0:0}  |  GC {1:0.0} MB", fps, Profiler.GetMonoUsedSizeLong() / (1024f * 1024f));
        }
    }
}
